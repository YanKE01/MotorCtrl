/*
 * @Author: Yanke@zjut.edu.cn
 * @Date: 2023-02-07 10:56:26
 * @LastEditors: LINKEEE 1435020085@qq.com
 * @LastEditTime: 2023-02-07 12:10:34
 * @FilePath: \F407IGT6_HALL\Ctrl\include\hall.h
 */
#ifndef _HAL_H
#define _HAL_H

#include "stdint.h"

void GetHallState(void);

#endif

