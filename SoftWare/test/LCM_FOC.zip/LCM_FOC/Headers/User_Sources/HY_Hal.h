/*
 * @Author: Yanke@zjut.edu.cn
 * @Date: 2023-05-15 21:08:20
 * @LastEditors: LINKEEE 1435020085@qq.com
 * @LastEditTime: 2023-05-16 10:15:30
 * @FilePath: \LCM_FOC\Headers\User_Sources\HY_Hal.h
 */
#ifndef _HY_DRIVER_H
#define _HY_DRIVER_H

#include "lcm32f037.h"

void HY_HalInit(void);
void HY_GpioTest(uint8_t status);


#endif
