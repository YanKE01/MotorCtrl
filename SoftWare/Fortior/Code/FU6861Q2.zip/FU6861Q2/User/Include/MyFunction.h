#ifndef _MYFUNCTION_H
#define _MYFUNCTION_H


void MyTaskLoop(void);


#endif