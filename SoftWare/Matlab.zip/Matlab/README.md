# FOC MATLAB仿真

## 1.初期ANTI PARK仿真实验的相关设置

* 模拟电角度增加可以使用Repeating Sequence模块搭建

![image-20230120154633381](https://pic-1256068477.cos.ap-shanghai.myqcloud.com/img/image-20230120154633381.png)

* 仿真时间与离散化设置

![image-20230120154836724](https://pic-1256068477.cos.ap-shanghai.myqcloud.com/img/image-20230120154836724.png)

<img src="https://pic-1256068477.cos.ap-shanghai.myqcloud.com/img/image-20230120154856182.png" alt="image-20230120154856182" style="zoom:50%;" />

![image-20230120155053854](https://pic-1256068477.cos.ap-shanghai.myqcloud.com/img/image-20230120155053854.png)

## 2.电流环

![image-20230125112441141](https://pic-1256068477.cos.ap-shanghai.myqcloud.com/img/image-20230125112441141.png)

![image-20230125112457371](https://pic-1256068477.cos.ap-shanghai.myqcloud.com/img/image-20230125112457371.png)

电流闭环系统如下：

![image-20230125112920335](https://pic-1256068477.cos.ap-shanghai.myqcloud.com/img/image-20230125112920335.png)