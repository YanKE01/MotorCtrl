#ifndef RTW_HEADER_pmsm_foc_capi_h
#define RTW_HEADER_pmsm_foc_capi_h
#include "pmsm_foc.h"
extern void pmsm_foc_InitializeDataMapInfo ( void ) ;
#endif
